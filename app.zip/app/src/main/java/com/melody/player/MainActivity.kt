package com.melody.player

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private val allSongs = mutableListOf<Song>()
    private var shownSongs = listOf<Song>()
    private var player: MediaPlayer? = null
    private var current = -1
    private lateinit var adapter: SongAdapter
    private lateinit var nowPlaying: TextView
    private lateinit var playButton: Button

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadSongs() else Toast.makeText(this, "Audio permission is needed to show your music.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        nowPlaying = findViewById(R.id.nowPlaying)
        playButton = findViewById(R.id.playPause)
        adapter = SongAdapter(emptyList()) { position -> playSong(shownSongs[position]) }
        findViewById<RecyclerView>(R.id.songList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        findViewById<EditText>(R.id.search).addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                shownSongs = allSongs.filter { it.title.contains(s.toString(), true) || it.artist.contains(s.toString(), true) }
                adapter.update(shownSongs)
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        playButton.setOnClickListener {
            val p = player
            if (p == null && current >= 0) playSong(allSongs[current])
            else if (p?.isPlaying == true) { p.pause(); playButton.text = "▶" }
            else { p?.start(); playButton.text = "Ⅱ" }
        }
        findViewById<Button>(R.id.next).setOnClickListener { move(1) }
        findViewById<Button>(R.id.prev).setOnClickListener { move(-1) }
        requestAudioPermission()
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadSongs()
        else permissionLauncher.launch(permission)
    }

    private fun loadSongs() {
        allSongs.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                allSongs.add(Song(id, cursor.getString(titleCol) ?: "Unknown title",
                    cursor.getString(artistCol) ?: "Unknown artist",
                    Uri.withAppendedPath(collection, id.toString())))
            }
        }
        shownSongs = allSongs.toList()
        adapter.update(shownSongs)
        if (allSongs.isEmpty()) Toast.makeText(this, "No music found on this device.", Toast.LENGTH_LONG).show()
    }

    private fun playSong(song: Song) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, song.uri)
                setOnCompletionListener { move(1) }
                prepare()
                start()
            }
            current = allSongs.indexOfFirst { it.id == song.id }
            nowPlaying.text = "${song.title}  •  ${song.artist}"
            playButton.text = "Ⅱ"
        } catch (e: Exception) {
            Toast.makeText(this, "Could not play this audio file.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun move(step: Int) {
        if (allSongs.isEmpty()) return
        val next = if (current < 0) 0 else (current + step + allSongs.size) % allSongs.size
        playSong(allSongs[next])
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
