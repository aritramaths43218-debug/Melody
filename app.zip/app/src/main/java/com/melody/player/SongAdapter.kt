package com.melody.player

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SongAdapter(
    private var songs: List<Song>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.Holder>() {
    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(android.R.id.text1)
        val artist: TextView = v.findViewById(android.R.id.text2)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(android.R.layout.two_line_list_item, parent, false)
        return Holder(v)
    }
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val song = songs[position]
        holder.title.text = song.title
        holder.artist.text = song.artist
        holder.title.setTextColor(0xFFFFFFFF.toInt())
        holder.artist.setTextColor(0xFFAAAAAF.toInt())
        holder.itemView.setOnClickListener { onClick(holder.bindingAdapterPosition) }
    }
    override fun getItemCount() = songs.size
    fun update(list: List<Song>) { songs = list; notifyDataSetChanged() }
}
